import { Luv2ShopValidators } from './luv2-shop-validators';

describe('Luv2ShopValidators', () => {
  it('should create an instance', () => {
    expect(new Luv2ShopValidators()).toBeTruthy();
  });
});
